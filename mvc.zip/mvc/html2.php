<html>
<head></head>
<body>
<?php
echo 'Title:' .$book->title . '<br/>';
echo 'author:' .$book->author . '<br/>';
echo 'Description:' .$book->description . '<br/>';
?>
</body>
</html>