<?php
include_once("model.php")
class controller{

	public $model;
	public function __construct()
	{
		$this->model =new model();

	}
	public function invoke()
	{
		if (!isset($))
	}
}




?>