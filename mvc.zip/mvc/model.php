<?php
include_once("model/Book.php");
class Model{
public function getBookList()
{
return array(
"jungle Book"=>new Book("jungle Book","R.Kipling","A Classic book."),
"Moonwalker"=> new Book("Moonwalker","j.Walker",""),
"PHP for Dummies"=>new Book("php for dummies","some smart guy","")
);}
public function getBook($title)
{
$allBooks=$this->getBookList();
return $allBooks[$title];
}
}
?>