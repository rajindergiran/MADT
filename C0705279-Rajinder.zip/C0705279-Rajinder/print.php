<script language="javascript">
function Clickheretoprint()
{ 
  var disp_setting="toolbar=yes,location=no,directories=yes,menubar=yes,"; 
      disp_setting+="scrollbars=yes,widtd=900, height=400, left=100, top=25"; 
  var content_vlue = document.getElementById("print_content").innerHTML; 
  
  var docprint=window.open("","",disp_setting); 
   docprint.document.open(); 
   docprint.document.write('<html><head><title>List of Passer</title>'); 
   docprint.document.write('</head><body onLoad="self.print()" style="widtd: 900px; font-size:16px; font-family:arial;">');          
   docprint.document.write(content_vlue);          
   docprint.document.write('</body></html>'); 
   docprint.document.close(); 
   docprint.focus(); 
}
</script>
    




<?php
	ob_start();
	session_start();
	require_once 'dbconnect.php';
	
	// if session is not set this will redirect to login page
	if( !isset($_SESSION['user']) ) {
		header("Location: index.php");
		exit;
	}
	// select loggedin users detail
	$res=mysql_query("SELECT * FROM users WHERE userId=".$_SESSION['user']);
	$userRow=mysql_fetch_array($res);
?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<title>Welcome - <?php echo $userRow['userEmail']; ?></title>
<link rel="stylesheet" href="assets/css/bootstrap.min.css" type="text/css"  />
<link rel="stylesheet" href="style.css" type="text/css" />
</head>
<body style="background-image: url(i.jpg);">

	<nav class="navbar navbar-inverse navbar-fixed-top">
      <div class="container">
        
        <div id="navbar" class="navbar-collapse collapse">
          <ul class="nav navbar-nav">

            <li class="active"><a href="home.php">HOME</a></li>
            <li><a href="add.php">Add Employees</a></li>
            <li><a href="table.php">Employee list</a></li>
           
            <li><a href="print.php">Download List</a></li>
            
          </ul>
          <ul class="nav navbar-nav navbar-right">
            
            <li class="dropdown" >
              <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
			  <span class="glyphicon glyphicon-user"></span>&nbsp;Hi' <?php echo $userRow['userEmail']; ?>&nbsp;<span class="caret"></span></a>
              <ul class="dropdown-menu">
                <li><a href="logout.php?logout"><span class="glyphicon glyphicon-log-out"></span>&nbsp;Sign Out</a></li>
              </ul>
            </li>
          </ul>
        </div><!--/.nav-collapse -->
      </div>
    </nav> 

	<div id="wrapper">

	<div >
    
    	<div class="page-header">
    	<h3>Payroll Management System.</h3>
    	</div>
        
        
    <p>
        <a href="javascript:Clickheretoprint()" class="btn btn-info btn-lg">
          <span class="glyphicon glyphicon-download-alt"></span> Download
        </a>Download full List of Employees
      </p> 

<div id="print_content">


<table  cellspacing="0"  border="1" class="table table-striped table-bordered table-hover table-condensed">
		<tr>
			
				<th width="10%"> ID </th>
				<th width="10%"> NAME </th>
				<th width="10%"> GENDER </th>
				<th width="13%"> DOB </th>
				<th width="13%"> ADDRESS </th>
				<th width="13%"> CITY </th>
				<th width="13%"> PROVINCE </th>
				<th width="13%"> POSTAL CODE </th>
				<th width="10%"> EMAIL </th>
				<th width="10%"> WEBSITE LINK </th>
				<th width="10%"> JOINIG DATE </th>
				<th width="13%"> ANNUAL BASIC PAY </th>
				<th width="15%"> TAX </th>
				
		</tr>
	<?php
		include('db.php');
		$result = mysql_query("SELECT * FROM users ORDER BY id ASC");
		while($row = mysql_fetch_array($result))
			{
			?>
				<tr class="record">
					
					<td><div align="left"><?php echo $row['id'] ?></div></td>
					<td><div align="left"><?php echo $row['name'] ?></div></td>
					<td><div align="left"><?php echo $row['gender'] ?></div></td>
					<td><div align="left"><?php echo $row['dob'] ?></div></td>
					<td><div align="left"><?php echo $row['address'] ?></div></td>
					<td><div align="left"><?php echo $row['city'] ?></div></td>
					<td><div align="left"><?php echo $row['province'] ?></div></td>
					<td><div align="left"><?php echo $row['post'] ?></div></td>
					<td><div align="left"><?php echo $row['email'] ?></div></td>
					<td><div align="left"><?php echo $row['link'] ?></div></td>
				    <td><div align="left"><?php echo $row['djoin'] ?></div></td>
					<td><div align="left"><?php echo $row['pay'] ?></div></td>
					<td><div align="left"><?php
					$pay=$row['pay'];
					if($pay<=45916)
				          {
				            $tax=$pay*0.15;
				          }

				          if ($pay>45916 and $pay<=91831) 
				          {
				            $tax=$pay*0.205;
				          }
				          if ($pay>91831 and $pay<=142353) 
				          {
				            $tax=$pay*0.26;
				          }
				          if ($pay>142353 and $pay<=202800) 
				          {
				            $tax=$pay*0.29;
				          }
				          if ($pay>202800) 
				          {
				            $tax=$pay*0.33;
				          }



					echo $tax;
					?></div></td>








					
					</tr>
			<?php
            }
		?> 
</table>
</div>

    </div>
    
    </div>
    
    <script src="assets/jquery-1.11.3-jquery.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    
</body>
</html>
<?php ob_end_flush(); ?>