<html>
<head>
	<title>Add Data</title>
</head>

<body>
<?php
//including the database connection file
include_once("config.php");

if(isset($_POST['Submit'])) {	
	$name = mysqli_real_escape_string($mysqli, $_POST['name']);
	$gender = mysqli_real_escape_string($mysqli, $_POST['gender']);
	$dob = mysqli_real_escape_string($mysqli, $_POST['dob']);
	$address = mysqli_real_escape_string($mysqli, $_POST['address']);
	$city = mysqli_real_escape_string($mysqli, $_POST['city']);
	$province = mysqli_real_escape_string($mysqli, $_POST['province']);
	$post = mysqli_real_escape_string($mysqli, $_POST['post']);
	$email = mysqli_real_escape_string($mysqli, $_POST['email']);
	$link = mysqli_real_escape_string($mysqli, $_POST['link']);
	$djoin = mysqli_real_escape_string($mysqli, $_POST['djoin']);
	$pay = mysqli_real_escape_string($mysqli, $_POST['pay']);

		
	// checking empty fields
	if(empty($name) || empty($gender) || empty($dob) || empty($address) || empty($city) || empty($province) ||empty($post) || empty($email) || empty($link) || empty($djoin) || empty($pay)) {
				
		if(empty($name)) {
			echo "<font color='red'>Name field is empty.</font><br/>";
		}

		if(empty($gender)) {
			echo "<font color='red'>Name field is empty.</font><br/>";
		}

		if(empty($dob)) {
			echo "<font color='red'>DoB field is empty.</font><br/>";
		}
		if(empty($address)) {
			echo "<font color='red'>Address field is empty.</font><br/>";
		}
		if(empty($city)) {
			echo "<font color='red'>City field is empty.</font><br/>";
		}

		if(empty($province)) {
			echo "<font color='red'>Province field is empty.</font><br/>";
		}

		if(empty($post)) {
			echo "<font color='red'>Post field is empty.</font><br/>";
		}
		
		if(empty($email)) {
			echo "<font color='red'>Email field is empty.</font><br/>";
		}
		if(empty($link)) {
			echo "<font color='red'>Email field is empty.</font><br/>";
		}
		if(empty($djoin)) {
			echo "<font color='red'>Email field is empty.</font><br/>";
		}
		if(empty($pay)) {
			echo "<font color='red'>Email field is empty.</font><br/>";
		}
		//link to the previous page
		echo "<br/><a href='javascript:self.history.back();'>Go Back</a>";
	} else { 
		// if all the fields are filled (not empty) 
			
		//insert data to database	
		$result = mysqli_query($mysqli, "INSERT INTO users(name,gender,dob,address,city,province,post,email,link,djoin,pay) VALUES('$name','$gender','$dob','$address','$city',
			'$province','$post','$email','$link','$djoin','$pay')");
		
		//display success message
		echo "<font color='green'>Data added successfully.";
		echo "<br/><a href='index.php'>View Result</a>";
	}
}
?>
</body>
</html>
