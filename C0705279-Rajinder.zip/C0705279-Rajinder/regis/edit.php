<?php
// including the database connection file
include_once("config.php");

if(isset($_POST['update']))
{	

	$id = mysqli_real_escape_string($mysqli, $_POST['id']);
	
	$name = mysqli_real_escape_string($mysqli, $_POST['name']);
	$gender = mysqli_real_escape_string($mysqli, $_POST['gender']);
	$dob = mysqli_real_escape_string($mysqli, $_POST['dob']);
	$address = mysqli_real_escape_string($mysqli, $_POST['address']);
	$city = mysqli_real_escape_string($mysqli, $_POST['city']);
	$province = mysqli_real_escape_string($mysqli, $_POST['province']);	
	$post = mysqli_real_escape_string($mysqli, $_POST['post']);	
	$email = mysqli_real_escape_string($mysqli, $_POST['email']);	
	$link = mysqli_real_escape_string($mysqli, $_POST['link']);	
	$djoin = mysqli_real_escape_string($mysqli, $_POST['djoin']);	
	$pay = mysqli_real_escape_string($mysqli, $_POST['pay']);	
	

	
	// checking empty fields
	if(empty($name) || empty($gender) || empty($dob) || empty($address) || empty($city) || empty($province) ||empty($post) || empty($email) || empty($link) || empty($djoin) || empty($pay)) {
		if(empty($id)) {
			echo "<font color='red'>ID field is empty.</font><br/>";
		}
				
		if(empty($name)) {
			echo "<font color='red'>Name field is empty.</font><br/>";
		}

		if(empty($gender)) {
			echo "<font color='red'>Name field is empty.</font><br/>";
		}

		if(empty($dob)) {
			echo "<font color='red'>DoB field is empty.</font><br/>";
		}
		if(empty($address)) {
			echo "<font color='red'>Address field is empty.</font><br/>";
		}
		if(empty($city)) {
			echo "<font color='red'>City field is empty.</font><br/>";
		}

		if(empty($province)) {
			echo "<font color='red'>Province field is empty.</font><br/>";
		}

		if(empty($post)) {
			echo "<font color='red'>Post field is empty.</font><br/>";
		}
		
		if(empty($email)) {
			echo "<font color='red'>Email field is empty.</font><br/>";
		}
		if(empty($link)) {
			echo "<font color='red'>Email field is empty.</font><br/>";
		}
		if(empty($djoin)) {
			echo "<font color='red'>Email field is empty.</font><br/>";
		}
		if(empty($pay)) {
			echo "<font color='red'>Email field is empty.</font><br/>";
		}




	} else {	
		//updating the table
		$result = mysqli_query($mysqli, "UPDATE users SET id='$id',name='$name',gender='$gender',dob='$dob',address='$address',city='$city',province='$province',post='$post',email='$email',link='$link',djoin='$djoin',pay='$pay' WHERE id=$id");
		
		//redirectig to the display page. In our case, it is index.php
		header("Location: index.php");
	}
}
?>
<?php
//getting id from url
$id = $_GET['id'];

//selecting data associated with this particular id
$result = mysqli_query($mysqli, "SELECT * FROM users WHERE id=$id");

while($res = mysqli_fetch_array($result))
{
	$id = $res['id'];
	$name = $res['name'];
	$gender = $res['gender'];
	$dob = $res['dob'];
	$address = $res['address'];
	$city = $res['city'];
	$province = $res['province'];
	$post = $res['post'];
	$email = $res['email'];
	$link = $res['link'];
	$djoin = $res['djoin'];
	$pay = $res['pay'];
	

}
?>




<!DOCTYPE html>
<html lang="en">
<head>
  <title>Registration</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>



<body >
  <a href="index.php">Home</a>
  <br/><br/>
  
  <form name="form1" method="post" action="edit.php" class="container" style="width: 30%">




     <div class="form-group">




      <label for="post">ID:</label>

     <input class="form-control" type="text" pattern="[0-9]*" maxlength="20" name="id" readonly value="<?php echo $id;?>">
    </div>
    
    

    <div class="form-group">
      <label >Name:</label>
     
      <input class="form-control" type="text" name="name" required value="<?php echo $name;?>">
    </div>






    <div class="form-group">
      <label for="gender">Male:</label>
      <input  class="form-control" type="radio" name="gender" value="M" required value="<?php echo $gender;?>">
      <label for="f">Female:</label>
      <input  class="form-control" type="radio" name="gender" value="F" required value="<?php echo $gender;?>">
    </div>





    <div class="form-group">
     <label for="date">Date Of Birth:</label>
     <input  class="form-control" type="date" name="dob" required value="<?php echo $dob;?>">
    </div>





    <div class="form-group">
      <label for="pwd">Addtess:</label>
      <textarea  class="form-control" name="address" required ><?php echo $address;?></textarea>
    </div>





    <div class="form-group">
    <label for="pwd">City:</label>
     <select   class="form-control" name="city" required >
          <option value="" selected="selected" disabled="disabled" ><?php echo $city;?></option>
          <option>Toronto</option>
          <option>Ottawa</option>
          <option>Edmonton</option>
          <option>Mississauga</option>
          <option>Winnipeg</option>
          <option>Vancouver</option>
          <option>Brampton</option>
          <option>Hamilton</option>
          <option>Quebec City</option>
          <option>Surrey</option>
          <option>Halifax</option>
          <option>London</option>
          <option>Vaughan</option>
          <option>Kitchener</option>
          <option>Burnaby</option>
          <option>Windsor</option>
          <option>Regina</option>
          <option>Richmond Hill</option>
        </select>
    </div>




    <div class="form-group">
    <label for="pwd">Province:</label>
     <select   class="form-control"  name="province" required >
          <option value="" selected="selected" disabled="disabled" ><?php echo $province;?></option>
          <option>Alberta</option>
          <option>British Columbia</option>
          <option>Manitoba</option>
          <option>Manitoba</option>
          <option>New Brunswick</option>
          <option>Newfoundland and Labrador</option>
          <option>Nova Scotia</option>
          <option>Ontario</option>
          <option>Prince Edward Island</option>
          <option>Quebec</option>
          <option>Saskatchewan</option>
          <option>Northwest Territories</option>
          <option>Nunavut </option>
          <option>Yukon</option>

        </select>
    </div>



   <div class="form-group">
      <label for="post">Postal Code:</label>
     <input class="form-control" type="text" pattern="[0-9]*" maxlength="6" name="post" required value="<?php echo $post;?>">
    </div>



    <div class="form-group">
      <label for="email">Email:</label>
      <input class="form-control" type="text" name="email" required value="<?php echo $email;?>">
    </div>






    <div class="form-group">
      <label for="email">Website link:</label>
       <input class="form-control" type="url" name="link" required value="<?php echo $link;?>">
    </div>


     <div class="form-group">
     <label for="date">Joining Date:</label>
     <input  class="form-control" type="date" name="djoin" required value="<?php echo $djoin;?>">
    </div>


     <div class="form-group">
      <label for="post">Annual Basic Pay:</label>
     <input class="form-control" type="text" pattern="[0-9]*" maxlength="20" name="pay" required value="<?php echo $pay;?>">
    </div>


  



   
        <input type="hidden" name="id" value=<?php echo $_GET['id'];?>>
        <input type="submit" name="update" value="Update">
      </tr>
    </table>
  </form>
</body>
</html>
