<script language="javascript">
function Clickheretoprint()
{ 
  var disp_setting="toolbar=yes,location=no,directories=yes,menubar=yes,"; 
      disp_setting+="scrollbars=yes,widtd=900, height=400, left=100, top=25"; 
  var content_vlue = document.getElementById("print_content").innerHTML; 
  
  var docprint=window.open("","",disp_setting); 
   docprint.document.open(); 
   docprint.document.write('<html><head><title>List of Passer</title>'); 
   docprint.document.write('</head><body onLoad="self.print()" style="widtd: 900px; font-size:16px; font-family:arial;">');          
   docprint.document.write(content_vlue);          
   docprint.document.write('</body></html>'); 
   docprint.document.close(); 
   docprint.focus(); 
}
</script>


<?php
// including the database connection file
include_once("config.php");

if(isset($_POST['update']))
{	

	$id = mysqli_real_escape_string($mysqli, $_POST['id']);
	
	$name = mysqli_real_escape_string($mysqli, $_POST['name']);
	$gender = mysqli_real_escape_string($mysqli, $_POST['gender']);
	$dob = mysqli_real_escape_string($mysqli, $_POST['dob']);
	$address = mysqli_real_escape_string($mysqli, $_POST['address']);
	$city = mysqli_real_escape_string($mysqli, $_POST['city']);
	$province = mysqli_real_escape_string($mysqli, $_POST['province']);	
	$post = mysqli_real_escape_string($mysqli, $_POST['post']);	
	$email = mysqli_real_escape_string($mysqli, $_POST['email']);	
	$link = mysqli_real_escape_string($mysqli, $_POST['link']);	
	$djoin = mysqli_real_escape_string($mysqli, $_POST['djoin']);	
	$pay = mysqli_real_escape_string($mysqli, $_POST['pay']);	
	

	
	// checking empty fields
	if(empty($name) || empty($gender) || empty($dob) || empty($address) || empty($city) || empty($province) ||empty($post) || empty($email) || empty($link) || empty($djoin) || empty($pay)) {
		if(empty($id)) {
			echo "<font color='red'>ID field is empty.</font><br/>";
		}
				
		if(empty($name)) {
			echo "<font color='red'>Name field is empty.</font><br/>";
		}

		if(empty($gender)) {
			echo "<font color='red'>Name field is empty.</font><br/>";
		}

		if(empty($dob)) {
			echo "<font color='red'>DoB field is empty.</font><br/>";
		}
		if(empty($address)) {
			echo "<font color='red'>Address field is empty.</font><br/>";
		}
		if(empty($city)) {
			echo "<font color='red'>City field is empty.</font><br/>";
		}

		if(empty($province)) {
			echo "<font color='red'>Province field is empty.</font><br/>";
		}

		if(empty($post)) {
			echo "<font color='red'>Post field is empty.</font><br/>";
		}
		
		if(empty($email)) {
			echo "<font color='red'>Email field is empty.</font><br/>";
		}
		if(empty($link)) {
			echo "<font color='red'>Email field is empty.</font><br/>";
		}
		if(empty($djoin)) {
			echo "<font color='red'>Email field is empty.</font><br/>";
		}
		if(empty($pay)) {
			echo "<font color='red'>Email field is empty.</font><br/>";
		}




	} else {	
		//updating the table
		$result = mysqli_query($mysqli, "UPDATE users SET id='$id',name='$name',gender='$gender',dob='$dob',address='$address',city='$city',province='$province',post='$post',email='$email',link='$link',djoin='$djoin',pay='$pay',tax='$tax' WHERE id=$id");
		
		//redirectig to the display page. In our case, it is index.php
		header("Location: index.php");
	}
}
?>
<?php
//getting id from url
$id = $_GET['id'];

//selecting data associated with this particular id
$result = mysqli_query($mysqli, "SELECT * FROM users WHERE id=$id");

while($res = mysqli_fetch_array($result))
{
	$id = $res['id'];
	$name = $res['name'];
	$gender = $res['gender'];
	$dob = $res['dob'];
	$address = $res['address'];
	$city = $res['city'];
	$province = $res['province'];
	$post = $res['post'];
	$email = $res['email'];
	$link = $res['link'];
	$djoin = $res['djoin'];
	$pay = $res['pay'];
	

}
?>





<?php
  ob_start();
  session_start();
  require_once 'dbconnect.php';
  
  // if session is not set this will redirect to login page
  if( !isset($_SESSION['user']) ) {
    header("Location: index.php");
    exit;
  }
  // select loggedin users detail
  $res=mysql_query("SELECT * FROM users WHERE userId=".$_SESSION['user']);
  $userRow=mysql_fetch_array($res);
?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Welcome - <?php echo $userRow['userEmail']; ?></title>
<link rel="stylesheet" href="assets/css/bootstrap.min.css" type="text/css"  />
<link rel="stylesheet" href="style.css" type="text/css" />
<script src="assets/jquery-1.11.3-jquery.min.js"></script>
<script src="assets/js/bootstrap.min.js"></script>
<style >
  
.receipt-content .logo a:hover {
  text-decoration: none;
  color: #7793C4; 
}

.receipt-content .invoice-wrapper {
  background: #FFF;
  border: 1px solid #CDD3E2;
  box-shadow: 0px 0px 1px #CCC;
  padding: 40px 40px 60px;
  margin-top: 40px;
  border-radius: 4px; 
}

.receipt-content .invoice-wrapper .payment-details span {
  color: #A9B0BB;
  display: block; 
}
.receipt-content .invoice-wrapper .payment-details a {
  display: inline-block;
  margin-top: 5px; 
}

.receipt-content .invoice-wrapper .line-items .print a {
  display: inline-block;
  border: 1px solid #9CB5D6;
  padding: 13px 13px;
  border-radius: 5px;
  color: #708DC0;
  font-size: 13px;
  -webkit-transition: all 0.2s linear;
  -moz-transition: all 0.2s linear;
  -ms-transition: all 0.2s linear;
  -o-transition: all 0.2s linear;
  transition: all 0.2s linear; 
}

.receipt-content .invoice-wrapper .line-items .print a:hover {
  text-decoration: none;
  border-color: #333;
  color: #333; 
}

.receipt-content {
  background: #ECEEF4; 
}
@media (min-width: 1200px) {
  .receipt-content .container {width: 900px; } 
}

.receipt-content .logo {
  text-align: center;
  margin-top: 50px; 
}

.receipt-content .logo a {
  font-family: Myriad Pro, Lato, Helvetica Neue, Arial;
  font-size: 36px;
  letter-spacing: .1px;
  color: #555;
  font-weight: 300;
  -webkit-transition: all 0.2s linear;
  -moz-transition: all 0.2s linear;
  -ms-transition: all 0.2s linear;
  -o-transition: all 0.2s linear;
  transition: all 0.2s linear; 
}

.receipt-content .invoice-wrapper .intro {
  line-height: 25px;
  color: #444; 
}

.receipt-content .invoice-wrapper .payment-info {
  margin-top: 25px;
  padding-top: 15px; 
}

.receipt-content .invoice-wrapper .payment-info span {
  color: #A9B0BB; 
}

.receipt-content .invoice-wrapper .payment-info strong {
  display: block;
  color: #444;
  margin-top: 3px; 
}

@media (max-width: 767px) {
  .receipt-content .invoice-wrapper .payment-info .text-right {
  text-align: left;
  margin-top: 20px; } 
}
.receipt-content .invoice-wrapper .payment-details {
  border-top: 2px solid #EBECEE;
  margin-top: 30px;
  padding-top: 20px;
  line-height: 22px; 
}


@media (max-width: 767px) {
  .receipt-content .invoice-wrapper .payment-details .text-right {
  text-align: left;
  margin-top: 20px; } 
}
.receipt-content .invoice-wrapper .line-items {
  margin-top: 40px; 
}
.receipt-content .invoice-wrapper .line-items .headers {
  color: #A9B0BB;
  font-size: 13px;
  letter-spacing: .3px;
  border-bottom: 2px solid #EBECEE;
  padding-bottom: 4px; 
}
.receipt-content .invoice-wrapper .line-items .items {
  margin-top: 8px;
  border-bottom: 2px solid #EBECEE;
  padding-bottom: 8px; 
}
.receipt-content .invoice-wrapper .line-items .items .item {
  padding: 10px 0;
  color: #696969;
  font-size: 15px; 
}
@media (max-width: 767px) {
  .receipt-content .invoice-wrapper .line-items .items .item {
  font-size: 13px; } 
}
.receipt-content .invoice-wrapper .line-items .items .item .amount {
  letter-spacing: 0.1px;
  color: #84868A;
  font-size: 16px;
 }
@media (max-width: 767px) {
  .receipt-content .invoice-wrapper .line-items .items .item .amount {
  font-size: 13px; } 
}

.receipt-content .invoice-wrapper .line-items .total {
  margin-top: 30px; 
}

.receipt-content .invoice-wrapper .line-items .total .extra-notes {
  float: left;
  width: 40%;
  text-align: left;
  font-size: 13px;
  color: #7A7A7A;
  line-height: 20px; 
}

@media (max-width: 767px) {
  .receipt-content .invoice-wrapper .line-items .total .extra-notes {
  width: 100%;
  margin-bottom: 30px;
  float: none; } 
}

.receipt-content .invoice-wrapper .line-items .total .extra-notes strong {
  display: block;
  margin-bottom: 5px;
  color: #454545; 
}

.receipt-content .invoice-wrapper .line-items .total .field {
  margin-bottom: 7px;
  font-size: 14px;
  color: #555; 
}

.receipt-content .invoice-wrapper .line-items .total .field.grand-total {
  margin-top: 10px;
  font-size: 16px;
  font-weight: 500; 
}

.receipt-content .invoice-wrapper .line-items .total .field.grand-total span {
  color: #20A720;
  font-size: 16px; 
}

.receipt-content .invoice-wrapper .line-items .total .field span {
  display: inline-block;
  margin-left: 20px;
  min-width: 85px;
  color: #84868A;
  font-size: 15px; 
}

.receipt-content .invoice-wrapper .line-items .print {
  margin-top: 50px;
  text-align: center; 
}



.receipt-content .invoice-wrapper .line-items .print a i {
  margin-right: 3px;
  font-size: 14px; 
}

.receipt-content .footer {
  margin-top: 40px;
  margin-bottom: 110px;
  text-align: center;
  font-size: 12px;
  color: #969CAD; 
}                    
</style>
</head>
<body >


  <nav class="navbar navbar-inverse navbar-fixed-top">
      <div class="container">
        
        <div id="navbar" class="navbar-collapse collapse">
          <ul class="nav navbar-nav">

            <li class="active"><a href="home.php">HOME</a></li>
            <li><a href="add.php">Add Employees</a></li>
            <li><a href="table.php">Employee list</a></li>
           
            <li><a href="print.php">Download List</a></li>
            
          </ul>
          <ul class="nav navbar-nav navbar-right">
            
            <li class="dropdown" >
              <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
        <span class="glyphicon glyphicon-user"></span>&nbsp;Hi' <?php echo $userRow['userEmail']; ?>&nbsp;<span class="caret"></span></a>
              <ul class="dropdown-menu">
                <li><a href="logout.php?logout"><span class="glyphicon glyphicon-log-out"></span>&nbsp;Sign Out</a></li>
              </ul>
            </li>
          </ul>
        </div><!--/.nav-collapse -->
      </div>
    </nav> 

  <div id="wrapper" style="background-image: url(i.jpg);">

  <div class="container" >
    
      <div class="page-header">
      <h3>Payroll Management System</h3>
      </div>
        
        

 
<div id="print_content" >

<div class="receipt-content">
    <div class="container bootstrap snippet">
    <div class="row">
      <div class="col-md-12">
        <div class="invoice-wrapper">
          <div class="intro">

           <h1> Hi <strong><?php echo $name;?></strong>,</h1>
            <br>
            This is the receipt for a payment of <strong>$<?php echo $pay-$tax; ?>.00</strong> (CAD) for your works
          </div>

          <div class="payment-info">
            <div class="row">
              <div class="col-sm-6">
                <h4><span>Payment No.</span>
                <strong><?php echo $id;?></strong></h4>
              </div>
              <div class="col-sm-6 text-right">
                <h5><span>Payment Date</span>
                <strong id="demo"></strong></h5>



<script>
document.getElementById("demo").innerHTML = Date();
</script>



              </div>
            </div>
          </div>

          <div class="payment-details">
            <div class="row">
              <div class="col-sm-6">
                <span>Client</span>
                <strong>
                  RSG Group<br>
                  Rajinder Singh Giran
                </strong>
                <p>
                  989 5th Avenue <br>
                  City of monterrey <br>
                  55839 <br>
                  USA <br>
                  <a href="#">
                    rsg.group@gmail.com
                  </a>
                </p>
              </div>
              <div class="col-sm-6 text-right">
                <span>Payment To</span>
                <strong>
                 <?php echo $name;?>
                </strong>
                <p>
                 <?php echo $address;?> <br>
                 <?php echo $city;?><br>
                 <?php echo $province;?><br>
                 <?php echo $post;?><br>
                 
                  
                  <a href="#">
                    <?php echo $email;?><br>
                  </a>
                </p>
              </div>
            </div>
          </div>

          <div class="line-items">
            <div class="headers clearfix">
              <div class="row">
                <div class="col-xs-4">Personal Information</div>
                <div class="col-xs-3"></div>
                <div class="col-xs-5 text-right"></div>
              </div>
            </div>
            <div class="items">
                <div class="row item">
                <div class="col-xs-4 desc">
                  Date of Joining
                </div>
                <div class="col-xs-3 qty">
                  <?php echo $djoin;?>
                </div>
                <div class="col-xs-5 amount text-right">
                  
                </div>
              </div>
              <div class="row item">
                <div class="col-xs-4 desc">
                  Gender
                </div>
                <div class="col-xs-3 qty">
                  <?php echo $gender;?>
                </div>
                <div class="col-xs-5 amount text-right">
                  
                </div>
              </div>
              <div class="row item">
                <div class="col-xs-4 desc">
                  Date of Birth
                </div>
                <div class="col-xs-3 qty">
                  <?php echo $dob;?>
                </div>
                <div class="col-xs-5 amount text-right">
                  
                </div>
              </div>
              <div class="row item">
                <div class="col-xs-4 desc">
                 Website Link 
                </div>
                <div class="col-xs-3 qty">
                <a href="#">
                     <?php echo $link;?>
                  </a>
                 
                </div>
                <div class="col-xs-5 amount text-right">
                  
                </div>
              </div>
            </div>
            <div class="total text-right">
              <p class="extra-notes" >
                <strong>Extra Notes</strong>
               15% on the first $45,916 of taxable income <br>
               20.5% on the next $45,915 of taxable income<br>
               26% on the next $50,522 of taxable income<br>
               29% on the next $60,447 of taxable income<br>
               33% of taxable income over $202,800<br>




              </p>
              <div class="field">
                Total Annual Basic Pay <span>$<?php echo $pay;?>.00</span>
              </div>
              <div class="field">
                Basic Pay <span>$<?php echo $pay;?>.00</span>
              </div>
              <div class="field">
              <?php



        if($pay<=45916)
          {
            $tax=$pay*0.15;
          }

          if ($pay>45916 and $pay<=91831) 
          {
            $tax=$pay*0.205;
          }
          if ($pay>91831 and $pay<=142353) 
          {
            $tax=$pay*0.26;
          }
          if ($pay>142353 and $pay<=202800) 
          {
            $tax=$pay*0.29;
          }
          if ($pay>202800) 
          {
            $tax=$pay*0.33;
          }

?>
                Tax <span>$<?php echo $tax; ?>.00</span>
              </div>
              <div class="field grand-total">
                Total <span>$<?php echo $pay-$tax; ?>.00</span>
              </div>

            </div>
            <div class="print">
              <a href="javascript:Clickheretoprint()" class="btn btn-info btn-lg">
                <i class="fa fa-print"></i>
                Print this receipt
              </a>
            </div>
          </div>

        </div>

        <div class="footer">
          Copyright © 2017. RSG Group
        </div>

      </div>

    </div>

    </div>

  </div>






</div>                    
  
    </div>
    
    
    
</body>
</html>
<?php ob_end_flush(); ?>
