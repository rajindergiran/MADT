<?php
//including the database connection file
include_once("config.php");

//fetching data in descending order (lastest entry first)
//$result = mysql_query("SELECT * FROM users ORDER BY id DESC"); // mysql_query is deprecated
$result = mysqli_query($mysqli, "SELECT * FROM users ORDER BY id DESC"); // using mysqli_query instead
?>




<?php
	ob_start();
	session_start();
	require_once 'dbconnect.php';
	
	// if session is not set this will redirect to login page
	if( !isset($_SESSION['user']) ) {
		header("Location: index.php");
		exit;
	}
	// select loggedin users detail
	$res=mysql_query("SELECT * FROM users WHERE userId=".$_SESSION['user']);
	$userRow=mysql_fetch_array($res);
?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Welcome - <?php echo $userRow['userEmail']; ?></title>
<link rel="stylesheet" href="assets/css/bootstrap.min.css" type="text/css"  />
<link rel="stylesheet" href="style.css" type="text/css" />



<script src="src/argiepolicarpio.js" type="text/javascript" charset="utf-8"></script>
<script src="src/application.js" type="text/javascript" charset="utf-8"></script>	
<script src="src/jquery.js" type="text/javascript"></script>
<script src="src/facebox.js" type="text/javascript"></script>


</head>
<body style="background-image: url(i.jpg);">

		<?php include 'nav.php'; ?>



	<div id="wrapper" >


	<div class="container" style="width: 100%" >
    
    	<div class="page-header">
    	<h3>Payroll Management System.</h3>
    	</div>
        
        <div class="row">
        <div class="col-lg-12">
        <h4>Registered Employee List</h4>
        </div>
        </div>


<div style="background-color: skyblue">


 <div class="row">
        <div class="col-md-4 col-md-offset-3" >
            <form action="" class="search-form">
                <div class="form-group has-feedback">
            		<label for="search" class="sr-only">Search</label>
            		

            		<input type="text" name="filter" value="" id="filter" class="form-control" placeholder="Search" />

              		<span class="glyphicon glyphicon-search form-control-feedback"></span>
            	</div>
            </form>
        </div>
    </div>
     





     <table  class="table table-striped table-bordered table-hover table-condensed"  >

	<tr bgcolor='#dddddd' >
	    <td >ID</td>
		<td>Name</td>
		<td>Gender</td>
		<td>Data of Birth</td>
		<td>Address</td>
		<td>City</td>
	    <td>Province</td>
	    <td>Postal Code</td>
		<td>Email</td>
		<td>Website link</td>
		<td>Joining Date</td>
		<td >Annual Basic Pay</td>

		
		<td  class="glyphicon glyphicon-pencil"  style="color: red " class="warning">
		<td class="glyphicon glyphicon-trash"></td></td>
	
	    </tr>

	<?php 
	//while($res = mysql_fetch_array($result)) { // mysql_fetch_array is deprecated, we need to use mysqli_fetch_array 
	while($res = mysqli_fetch_array($result)) { 		
		echo "<tr >";
		echo "<td >".$res['id']."</td>";
		echo "<td>".$res['name']."</td>";
		echo "<td>".$res['gender']."</td>";
		echo "<td>".$res['dob']."</td>";
		echo "<td>".$res['address']."</td>";
		echo "<td>".$res['city']."</td>";
		echo "<td>".$res['province']."</td>";
		echo "<td>".$res['post']."</td>";
		echo "<td>".$res['email']."</td>";
		echo "<td>".$res['link']."</td>";
		echo "<td>".$res['djoin']."</td>";
		echo "<td>".$res['pay']."</td>";

		echo "<td>
		<a href=\"edit.php?id=$res[id]\">Edit</a> | 
		<a href=\"res.php?id=$res[id]\">print</a> | 
		<a href=\"delete.php?id=$res[id]\" onClick=\"return confirm('Are you sure you want to delete?')\">Delete</a></td>";		
	}
	?>
	</table>
    </div>
    </div>

    
    </div>

    
    <script src="assets/jquery-1.11.3-jquery.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    
</body>
</html>
<?php ob_end_flush(); ?>
