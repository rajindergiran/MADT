
<script language="javascript">
function Clickheretoprint()
{ 
  var disp_setting="toolbar=yes,location=no,directories=yes,menubar=yes,"; 
      disp_setting+="scrollbars=yes,widtd=900, height=400, left=100, top=25"; 
  var content_vlue = document.getElementById("print_content").innerHTML; 
  
  var docprint=window.open("","",disp_setting); 
   docprint.document.open(); 
   docprint.document.write('<html><head><title>List of Passer</title>'); 
   docprint.document.write('</head><body onLoad="self.print()" style="widtd: 900px; font-size:16px; font-family:arial;">');          
   docprint.document.write(content_vlue);          
   docprint.document.write('</body></html>'); 
   docprint.document.close(); 
   docprint.focus(); 
}
</script>

<?php
// including the database connection file
include_once("config.php");

if(isset($_POST['update']))
{	

	$id = mysqli_real_escape_string($mysqli, $_POST['id']);
	
	$name = mysqli_real_escape_string($mysqli, $_POST['name']);
	$gender = mysqli_real_escape_string($mysqli, $_POST['gender']);
	$dob = mysqli_real_escape_string($mysqli, $_POST['dob']);
	$address = mysqli_real_escape_string($mysqli, $_POST['address']);
	$city = mysqli_real_escape_string($mysqli, $_POST['city']);
	$province = mysqli_real_escape_string($mysqli, $_POST['province']);	
	$post = mysqli_real_escape_string($mysqli, $_POST['post']);	
	$email = mysqli_real_escape_string($mysqli, $_POST['email']);	
	$link = mysqli_real_escape_string($mysqli, $_POST['link']);	
	$djoin = mysqli_real_escape_string($mysqli, $_POST['djoin']);	
	$pay = mysqli_real_escape_string($mysqli, $_POST['pay']);	
	

	
	// checking empty fields
	if(empty($name) || empty($gender) || empty($dob) || empty($address) || empty($city) || empty($province) ||empty($post) || empty($email) || empty($link) || empty($djoin) || empty($pay)) {
		if(empty($id)) {
			echo "<font color='red'>ID field is empty.</font><br/>";
		}
				
		if(empty($name)) {
			echo "<font color='red'>Name field is empty.</font><br/>";
		}

		if(empty($gender)) {
			echo "<font color='red'>Name field is empty.</font><br/>";
		}

		if(empty($dob)) {
			echo "<font color='red'>DoB field is empty.</font><br/>";
		}
		if(empty($address)) {
			echo "<font color='red'>Address field is empty.</font><br/>";
		}
		if(empty($city)) {
			echo "<font color='red'>City field is empty.</font><br/>";
		}

		if(empty($province)) {
			echo "<font color='red'>Province field is empty.</font><br/>";
		}

		if(empty($post)) {
			echo "<font color='red'>Post field is empty.</font><br/>";
		}
		
		if(empty($email)) {
			echo "<font color='red'>Email field is empty.</font><br/>";
		}
		if(empty($link)) {
			echo "<font color='red'>Email field is empty.</font><br/>";
		}
		if(empty($djoin)) {
			echo "<font color='red'>Email field is empty.</font><br/>";
		}
		if(empty($pay)) {
			echo "<font color='red'>Email field is empty.</font><br/>";
		}




	} else {	
		//updating the table
		$result = mysqli_query($mysqli, "UPDATE users SET id='$id',name='$name',gender='$gender',dob='$dob',address='$address',city='$city',province='$province',post='$post',email='$email',link='$link',djoin='$djoin',pay='$pay',tax='$tax' WHERE id=$id");
		
		//redirectig to the display page. In our case, it is index.php
		header("Location: index.php");
	}
}
?>
<?php
//getting id from url
$id = $_GET['id'];

//selecting data associated with this particular id
$result = mysqli_query($mysqli, "SELECT * FROM users WHERE id=$id");

while($res = mysqli_fetch_array($result))
{
	$id = $res['id'];
	$name = $res['name'];
	$gender = $res['gender'];
	$dob = $res['dob'];
	$address = $res['address'];
	$city = $res['city'];
	$province = $res['province'];
	$post = $res['post'];
	$email = $res['email'];
	$link = $res['link'];
	$djoin = $res['djoin'];
	$pay = $res['pay'];
	

}
?>





<?php
  ob_start();
  session_start();
  require_once 'dbconnect.php';
  
  // if session is not set this will redirect to login page
  if( !isset($_SESSION['user']) ) {
    header("Location: index.php");
    exit;
  }
  // select loggedin users detail
  $res=mysql_query("SELECT * FROM users WHERE userId=".$_SESSION['user']);
  $userRow=mysql_fetch_array($res);
?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Welcome - <?php echo $userRow['userEmail']; ?></title>
<link rel="stylesheet" href="assets/css/bootstrap.min.css" type="text/css"  />
<link rel="stylesheet" href="style.css" type="text/css" />
<style >
  label{
    size: 200px;
  }
</style>
</head>
<body >


  <nav class="navbar navbar-inverse navbar-fixed-top">
      <div class="container">
        
        <div id="navbar" class="navbar-collapse collapse">
          <ul class="nav navbar-nav">

            <li class="active"><a href="home.php">HOME</a></li>
            <li><a href="add.php">Add Employees</a></li>
            <li><a href="table.php">Employee list</a></li>
           
            <li><a href="print.php">Download List</a></li>
            
          </ul>
          <ul class="nav navbar-nav navbar-right">
            
            <li class="dropdown" >
              <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
        <span class="glyphicon glyphicon-user"></span>&nbsp;Hi' <?php echo $userRow['userEmail']; ?>&nbsp;<span class="caret"></span></a>
              <ul class="dropdown-menu">
                <li><a href="logout.php?logout"><span class="glyphicon glyphicon-log-out"></span>&nbsp;Sign Out</a></li>
              </ul>
            </li>
          </ul>
        </div><!--/.nav-collapse -->
      </div>
    </nav> 

  <div id="wrapper" style="background-image: url(i.jpg);">

  <div class="container" >
    
      <div class="page-header">
      <h3>Payroll Management System</h3>
      </div>
        
        <a href="javascript:Clickheretoprint()" class="btn btn-info btn-lg">
          <span class="glyphicon glyphicon-download-alt"></span> Download
        </a>
<div class="container" style="background-color: skyblue">
<div class="container" style="width: 40%">
  
    
        
    

<div id="print_content" >

        <form name="form1" method="post" action="edit.php" style="margin-left: 0%">
<p id="demo"></p>

<script>
document.getElementById("demo").innerHTML = Date();
</script>


     <div class="form-group">

      <label >ID:</label>
      <label ><?php echo $id;?></label>
      
    </div>
    
    <br>

    <div class="form-group">
      <label >Name:</label>
      <label><?php echo $name;?></label>
     
     
    </div>






    <div class="form-group">
      <label for="gender">Gender:</label>
      <label><?php echo $gender;?></label>
      
    </div>





    <div class="form-group">
     <label for="date">Date Of Birth:</label>
     <label><?php echo $dob;?></label>
     
    </div>





    <div class="form-group">
      <label for="pwd">Addtess:</label>
      <label><?php echo $address;?></label>
      
    </div>





    <div class="form-group">
    <label for="pwd">City:</label>
    <label><?php echo $city;?></label>
     
    </div>




    <div class="form-group">
    <label for="pwd">Province:</label>
    <label><?php echo $province;?></label>
    
    </div>



   <div class="form-group">
      <label for="post">Postal Code:</label>
      <label><?php echo $post;?></label>
    </div>



    <div class="form-group">
      <label for="email">Email:</label>
      <label><?php echo $email;?></label>
    </div>






    <div class="form-group">
      <label for="email">Website link:</label>
      <label><?php echo $link;?></label>
    </div>


     <div class="form-group">
     <label for="date">Joining Date:</label>
     <label><?php echo $djoin;?></label>
    
    </div>


     <div class="form-group">
      <label for="post">Annual Basic Pay:</label>
      <label><?php echo $pay;?></label>
     
    </div>

  
 <?php



        if($pay<=45916)
          {
            $tax=$pay*0.15;
          }

          if ($pay>45916 and $pay<=91831) 
          {
            $tax=$pay*0.205;
          }
          if ($pay>91831 and $pay<=142353) 
          {
            $tax=$pay*0.26;
          }
          if ($pay>142353 and $pay<=202800) 
          {
            $tax=$pay*0.29;
          }
          if ($pay>202800) 
          {
            $tax=$pay*0.33;
          }

?>
<div class="form-group">
 <label for="post">Tax:</label>

<label >
   <?php echo $tax; ?>
    
</label>
</div>
<div class="form-group">
<label for="post">Total Pay:</label>

<label >
   <?php echo $pay-$tax; ?>

    
</label>
</div>




  
       
      </tr>

   
  </form>
</div>
    
    </div>
    </div>
    </div>
    
    <script src="assets/jquery-1.11.3-jquery.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    
<div class="receipt-content">
    <div class="container bootstrap snippet">
    <div class="row">
      <div class="col-md-12">
        <div class="invoice-wrapper">
          <div class="intro">
            Hi <strong>John McClane</strong>, 
            <br>
            This is the receipt for a payment of <strong>$312.00</strong> (USD) for your works
          </div>

          <div class="payment-info">
            <div class="row">
              <div class="col-sm-6">
                <span>Payment No.</span>
                <strong>434334343</strong>
              </div>
              <div class="col-sm-6 text-right">
                <span>Payment Date</span>
                <strong>Jul 09, 2014 - 12:20 pm</strong>
              </div>
            </div>
          </div>

          <div class="payment-details">
            <div class="row">
              <div class="col-sm-6">
                <span>Client</span>
                <strong>
                  Andres felipe posada
                </strong>
                <p>
                  989 5th Avenue <br>
                  City of monterrey <br>
                  55839 <br>
                  USA <br>
                  <a href="#">
                    jonnydeff@gmail.com
                  </a>
                </p>
              </div>
              <div class="col-sm-6 text-right">
                <span>Payment To</span>
                <strong>
                  Juan fernando arias
                </strong>
                <p>
                  344 9th Avenue <br>
                  San Francisco <br>
                  99383 <br>
                  USA <br>
                  <a href="#">
                    juanfer@gmail.com
                  </a>
                </p>
              </div>
            </div>
          </div>

          <div class="line-items">
            <div class="headers clearfix">
              <div class="row">
                <div class="col-xs-4">Description</div>
                <div class="col-xs-3">Quantity</div>
                <div class="col-xs-5 text-right">Amount</div>
              </div>
            </div>
            <div class="items">
              <div class="row item">
                <div class="col-xs-4 desc">
                  Html theme
                </div>
                <div class="col-xs-3 qty">
                  3
                </div>
                <div class="col-xs-5 amount text-right">
                  $60.00
                </div>
              </div>
              <div class="row item">
                <div class="col-xs-4 desc">
                  Bootstrap snippet
                </div>
                <div class="col-xs-3 qty">
                  1
                </div>
                <div class="col-xs-5 amount text-right">
                  $20.00
                </div>
              </div>
              <div class="row item">
                <div class="col-xs-4 desc">
                  Snippets on bootdey 
                </div>
                <div class="col-xs-3 qty">
                  2
                </div>
                <div class="col-xs-5 amount text-right">
                  $18.00
                </div>
              </div>
            </div>
            <div class="total text-right">
              <p class="extra-notes">
                <strong>Extra Notes</strong>
                Please send all items at the same time to shipping address by next week.
                Thanks a lot.
              </p>
              <div class="field">
                Subtotal <span>$379.00</span>
              </div>
              <div class="field">
                Shipping <span>$0.00</span>
              </div>
              <div class="field">
                Discount <span>4.5%</span>
              </div>
              <div class="field grand-total">
                Total <span>$312.00</span>
              </div>
            </div>

            <div class="print">
              <a href="#">
                <i class="fa fa-print"></i>
                Print this receipt
              </a>
            </div>
          </div>
        </div>

        <div class="footer">
          Copyright © 2014. company name
        </div>
      </div>
    </div>
  </div>
</div>                    
</body>
</html>
<?php ob_end_flush(); ?>
