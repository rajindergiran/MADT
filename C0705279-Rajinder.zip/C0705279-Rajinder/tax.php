
<?php
	require_once('auth.php');
?>



<?php
	ob_start();
	session_start();
	require_once 'dbconnect.php';
	
	// if session is not set this will redirect to login page
	if( !isset($_SESSION['user']) ) {
		header("Location: index.php");
		exit;
	}
	// select loggedin users detail
	$res=mysql_query("SELECT * FROM users WHERE userId=".$_SESSION['user']);
	$userRow=mysql_fetch_array($res);
?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Welcome - <?php echo $userRow['userEmail']; ?></title>
<link rel="stylesheet" href="assets/css/bootstrap.min.css" type="text/css"  />
<link rel="stylesheet" href="style.css" type="text/css" />
</head>
<body style="background-image: url(i.jpg);">

	<nav class="navbar navbar-inverse navbar-fixed-top">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
           
          </button>
          <a class="navbar-brand" href="Home.php">Home</a>
        </div>
        <div id="navbar" class="navbar-collapse collapse">
          <ul class="nav navbar-nav">
            <li class="active"><a href="add.php">Add Employees</a></li>
           
            <li><a href="index 2.php">Employee list</a></li>
          </ul>
          <ul class="nav navbar-nav navbar-right">
            
            <li class="dropdown" >
              <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
			  <span class="glyphicon glyphicon-user"></span>&nbsp;Hi' <?php echo $userRow['userEmail']; ?>&nbsp;<span class="caret"></span></a>
              <ul class="dropdown-menu">
                <li><a href="logout.php?logout"><span class="glyphicon glyphicon-log-out"></span>&nbsp;Sign Out</a></li>
              </ul>
            </li>
          </ul>
        </div><!--/.nav-collapse -->
      </div>
    </nav> 

	<div id="wrapper">

	<div >
    
    	<div class="page-header">
    	<h3>Payroll Management System.</h3>
    	</div>
        
        <div class="row">
        <div class="col-lg-12">
        <h1>welcome</h1>
        </div>
        </div>

    <table style="width: 100%" border=11 class="table table-condensed">
		<thead>
			<tr>
				<th > ID </th>
				<th > NAME </th>
				<th> GENDER </th>
				<th > DATE OF BIRTH </th>
				<th> ADDRESS </th>
				<th > CITY </th>
				<th> PROVINCE </th>
				<th> POST CODE </th>
				<th> EMAIL </th>
				<th > WEB SITE LINK </th>
				<th > JOINING DATE </th>
				<th > ANNUAL BASIC PAY </th>
				<th > TAX </th>
				
			</tr>
		</thead>
		<tbody>
		<?php
			include('db.php');
			$result = mysql_query("SELECT * FROM users ORDER BY id ASC");
			while($row = mysql_fetch_array($result))
				{
				?>
					<tr >
					<td><div align="left"><?php echo $row['id'] ?></div></td>
					<td><div align="left"><?php echo $row['name'] ?></div></td>
					<td><div align="left"><?php echo $row['gender'] ?></div></td>
					<td><div align="left"><?php echo $row['dob'] ?></div></td>
					<td><div align="left"><?php echo $row['address'] ?></div></td>
					<td><div align="left"><?php echo $row['city'] ?></div></td>
					<td><div align="left"><?php echo $row['id'] ?></div></td>
					
					<td><div align="left"><?php echo $row['pay'] ?></div></td>
					<td><div align="left"><?php echo $row['id'] ?></div></td>
					
					<td><div align="left"><?php echo $row['pay'] ?></div></td>
					<td><div align="left"><?php echo $row['id'] ?></div></td>
					
					<td><div align="left"><?php echo $row['pay'] ?></div></td>
					<td><div align="left"><?php echo $row['id'] ?></div></td>
					
					<td><div align="left"><?php echo $row['pay'] ?></div></td>
					
					<td><div align="left">
					<?php
					$pay= $row['pay'];
					
					if($pay==100)
					{
						$tax=$pay*0.02;
					}

					if ($pay==200) 
					{
						$tax=$pay*0.05;
					}
								
									echo $tax;
					?>
						

					</div></td>
					

				<td><a href=\"edit.php?id=$res[id]\">Edit</a> | 
		<a href=\"delete.php?id=$res[id]\" onClick=\"return confirm('Are you sure you want to delete?')\">Delete</a></td>";	

                   

					</tr>
				    <?php
                }
			?> 
		</tbody>
	</table>
    </div>
    
    </div>
    
    <script src="assets/jquery-1.11.3-jquery.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    
</body>
</html>
<?php ob_end_flush(); ?>
